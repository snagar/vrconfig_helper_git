<h1>Xplm Menus</h1>

---

<div class="sym-block sym-enum" data-name="XPLMMenuCheck" data-type="enum" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMMenuCheck { .symbol-title }

<span class="sym-badge badge-enum">enum</span>

</div>

These enumerations define the various 'check' states for an X-Plane menu.  'Checking'
in X-Plane actually appears as a light which may or may not be lit.  So there are
three possible states.

<div class="enum-table" markdown="1">

| Name | Value | Description |
|:--|:--|:--|
| xplm_Menu_NoCheck | 0 | There is no symbol to the left of the menu item. |
| xplm_Menu_Unchecked | 1 | The menu has a mark next to it that is unmarked (not lit). |
| xplm_Menu_Checked | 2 | The menu has a mark next to it that is checked (lit). |

</div>

**Used by:**

- [XPLMCheckMenuItem](#xplmcheckmenuitem)
- [XPLMCheckMenuItemState](#xplmcheckmenuitemstate)

</div>

---

<div class="sym-block sym-typedef" data-name="XPLMMenuID" data-type="typedef" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMMenuID { .symbol-title }

<span class="sym-badge badge-typedef">typedef</span>

</div>

This is a unique ID for each menu you create.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">local my_menuID = nil  -- XPLMMenuID</code></pre>
</div>


**Used by:**

- [XPLMAppendMenuItem](#xplmappendmenuitem)
- [XPLMAppendMenuItemWithCommand](#xplmappendmenuitemwithcommand)
- [XPLMAppendMenuSeparator](#xplmappendmenuseparator)
- [XPLMCheckMenuItem](#xplmcheckmenuitem)
- [XPLMCheckMenuItemState](#xplmcheckmenuitemstate)
- [XPLMClearAllMenuItems](#xplmclearallmenuitems)
- [XPLMCreateMenu](#xplmcreatemenu)
- [XPLMDestroyMenu](#xplmdestroymenu)
- [XPLMEnableMenuItem](#xplmenablemenuitem)
- [XPLMRemoveMenuItem](#xplmremovemenuitem)
- [XPLMSetMenuItemName](#xplmsetmenuitemname)
</div>

---

<div class="sym-block sym-callback" data-name="XPLMMenuHandler_f" data-type="callback" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMMenuHandler_f { .symbol-title }

<span class="sym-badge badge-cb">callback</span>

</div>

A menu handler function takes two reference pointers, one for the menu (specified
when the menu was created) and one for the item (specified when the item was created).

<div class="lua-code" markdown="1">
<pre><code class="language-lua">function my_MenuHandler_callback(
    inMenuRef,    -- any Lua var/table
    inItemRef     -- any Lua var/table
)
    -- your code here
end</code></pre>
</div>

</div>

---

<div class="sym-block sym-function" data-name="XPLMFindPluginsMenu" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMFindPluginsMenu { .symbol-title }

<span class="sym-badge badge-fn">function</span>

</div>

This function returns the ID of the plug-ins menu, which is created for you at startup.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">-- returns XPLMMenuID -> assign to local/var
local my_menuID = XPLMFindPluginsMenu(
)</code></pre>
</div>

</div>

---

<div class="sym-block sym-function" data-name="XPLMFindAircraftMenu" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMFindAircraftMenu { .symbol-title }

<span class="sym-badge badge-fn">function</span> <span class="sym-badge badge-version">XPLM300</span>

</div>

This function returns the ID of the menu for the currently-loaded aircraft,
used for showing aircraft-specific commands.

The aircraft menu is created by X-Plane at startup, but it remains hidden until it is populated via
XPLMAppendMenuItem() or XPLMAppendMenuItemWithCommand().

Only plugins loaded with the user's current aircraft are allowed to access the aircraft menu.
For all other plugins, this will return NULL, and any attempts to add menu items to it will fail.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">-- returns XPLMMenuID -> assign to local/var
local my_menuID = XPLMFindAircraftMenu(
)</code></pre>
</div>

</div>

---

<div class="sym-block sym-function" data-name="XPLMCreateMenu" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMCreateMenu { .symbol-title }

<span class="sym-badge badge-fn">function</span>

</div>

This function creates a new menu and returns its ID.  It returns NULL if the menu cannot
be created.  Pass in a parent menu ID and an item index to create a submenu, or NULL
for the parent menu to put the menu in the menu bar.  The menu's name is only used if
the menu is in the menubar.  You also pass a handler function and a menu reference value.
Pass NULL for the handler if you do not need callbacks from the menu (for example, if it
only contains submenus).

Important: you must pass a valid, non-empty menu title even if the menu is a submenu where
the title is not visible.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">-- returns XPLMMenuID -> assign to local/var
local my_menuID = XPLMCreateMenu(
    inName,          -- string
    inParentMenu,    -- XPLMMenuID
    inParentItem,    -- int
    inHandler,       -- see XPLMMenuHandler_f
    inMenuRef        -- any Lua var/table
)</code></pre>
</div>


**See associated types:**

- [XPLMMenuHandler_f](#xplmmenuhandler_f)
- [XPLMMenuID](#xplmmenuid)
</div>

---

<div class="sym-block sym-function" data-name="XPLMDestroyMenu" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMDestroyMenu { .symbol-title }

<span class="sym-badge badge-fn">function</span>

</div>

This function destroys a menu that you have created.  Use this to remove a submenu
if necessary.  (Normally this function will not be necessary.)

<div class="lua-code" markdown="1">
<pre><code class="language-lua">XPLMDestroyMenu(
    inMenuID     -- XPLMMenuID
)</code></pre>
</div>


**See associated types:**

- [XPLMMenuID](#xplmmenuid)
</div>

---

<div class="sym-block sym-function" data-name="XPLMClearAllMenuItems" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMClearAllMenuItems { .symbol-title }

<span class="sym-badge badge-fn">function</span>

</div>

This function removes all menu items from a menu, allowing you to rebuild
it.  Use this function if you need to change the number of items on a menu.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">XPLMClearAllMenuItems(
    inMenuID     -- XPLMMenuID
)</code></pre>
</div>


**See associated types:**

- [XPLMMenuID](#xplmmenuid)
</div>

---

<div class="sym-block sym-function" data-name="XPLMAppendMenuItem" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMAppendMenuItem { .symbol-title }

<span class="sym-badge badge-fn">function</span>

</div>

This routine appends a new menu item to the bottom of a menu and returns its index.
Pass in the menu to add the item to, the items name, and a void * ref for this item.

Returns a negative index if the append failed (due to an invalid parent menu argument).

Note that all menu indices returned are relative to your plugin's menus only; if your plugin
creates two sub-menus in the Plugins menu at different times, it doesn't matter how many other
plugins also create sub-menus of Plugins in the intervening time: your sub-menus will be
given menu indices 0 and 1.
(The SDK does some work in the back-end to filter out menus that are irrelevant to your plugin
in order to deliver this consistency for each plugin.)

<div class="lua-code" markdown="1">
<pre><code class="language-lua">-- returns int -> assign to local/var
local my_result = XPLMAppendMenuItem(
    inMenu,                    -- XPLMMenuID
    inItemName,                -- string
    inItemRef,                 -- any Lua var/table
    inDeprecatedAndIgnored     -- int
)</code></pre>
</div>


**See associated types:**

- [XPLMMenuID](#xplmmenuid)
</div>

---

<div class="sym-block sym-function" data-name="XPLMAppendMenuItemWithCommand" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMAppendMenuItemWithCommand { .symbol-title }

<span class="sym-badge badge-fn">function</span> <span class="sym-badge badge-version">XPLM300</span>

</div>

Like XPLMAppendMenuItem(), but instead of the new menu item triggering the XPLMMenuHandler_f of
the containiner menu, it will simply execute the command you pass in. Using a command for your menu item
allows the user to bind a keyboard shortcut to the command and see that shortcut represented in the menu.

Returns a negative index if the append failed (due to an invalid parent menu argument).

Like XPLMAppendMenuItem(), all menu indices are relative to your plugin's menus only.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">-- returns int -> assign to local/var
local my_result = XPLMAppendMenuItemWithCommand(
    inMenu,                -- XPLMMenuID
    inItemName,            -- string
    inCommandToExecute     -- XPLMCommandRef
)</code></pre>
</div>


**See associated types:**

- [XPLMMenuID](#xplmmenuid)
</div>

---

<div class="sym-block sym-function" data-name="XPLMAppendMenuSeparator" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMAppendMenuSeparator { .symbol-title }

<span class="sym-badge badge-fn">function</span>

</div>

This routine adds a separator to the end of a menu.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">XPLMAppendMenuSeparator(
    inMenu     -- XPLMMenuID
)</code></pre>
</div>


**See associated types:**

- [XPLMMenuID](#xplmmenuid)
</div>

---

<div class="sym-block sym-function" data-name="XPLMSetMenuItemName" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMSetMenuItemName { .symbol-title }

<span class="sym-badge badge-fn">function</span>

</div>

This routine changes the name of an existing menu item.  Pass in the menu ID and
the index of the menu item.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">XPLMSetMenuItemName(
    inMenu,                    -- XPLMMenuID
    inIndex,                   -- int
    inItemName,                -- string
    inDeprecatedAndIgnored     -- int
)</code></pre>
</div>


**See associated types:**

- [XPLMMenuID](#xplmmenuid)
</div>

---

<div class="sym-block sym-function" data-name="XPLMCheckMenuItem" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMCheckMenuItem { .symbol-title }

<span class="sym-badge badge-fn">function</span>

</div>

Set whether a menu item is checked.  Pass in the menu ID and item index.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">XPLMCheckMenuItem(
    inMenu,     -- XPLMMenuID
    index,      -- int
    inCheck     -- XPLMMenuCheck
)</code></pre>
</div>


**See associated types:**

- [XPLMMenuCheck](#xplmmenucheck)
- [XPLMMenuID](#xplmmenuid)
</div>

---

<div class="sym-block sym-function" data-name="XPLMCheckMenuItemState" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMCheckMenuItemState { .symbol-title }

<span class="sym-badge badge-fn">function</span>

</div>

This routine returns whether a menu item is checked or not.
A menu item's check mark may be on or off, or a menu may
not have an icon at all.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">-- returns a table of out values
local outs = XPLMCheckMenuItemState(
    inMenu,    -- XPLMMenuID
    index      -- int
)
-- outs = { outCheck }</code></pre>
</div>


**See associated types:**

- [XPLMMenuCheck](#xplmmenucheck)
- [XPLMMenuID](#xplmmenuid)
</div>

---

<div class="sym-block sym-function" data-name="XPLMEnableMenuItem" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMEnableMenuItem { .symbol-title }

<span class="sym-badge badge-fn">function</span>

</div>

Sets whether this menu item is enabled.  Items start out enabled.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">XPLMEnableMenuItem(
    inMenu,     -- XPLMMenuID
    index,      -- int
    enabled     -- boolean
)</code></pre>
</div>


**See associated types:**

- [XPLMMenuID](#xplmmenuid)
</div>

---

<div class="sym-block sym-function" data-name="XPLMRemoveMenuItem" data-type="function" markdown="1">

<div class="sym-title-row" markdown="1">

## XPLMRemoveMenuItem { .symbol-title }

<span class="sym-badge badge-fn">function</span> <span class="sym-badge badge-version">XPLM210</span>

</div>

Removes one item from a menu.  Note that all menu items below are moved up one; your plugin
must track the change in index numbers.

<div class="lua-code" markdown="1">
<pre><code class="language-lua">XPLMRemoveMenuItem(
    inMenu,     -- XPLMMenuID
    inIndex     -- int
)</code></pre>
</div>


**See associated types:**

- [XPLMMenuID](#xplmmenuid)
</div>

---



<!-- whitespace for navigation purposes -->
<div class="page-spacer"></div>